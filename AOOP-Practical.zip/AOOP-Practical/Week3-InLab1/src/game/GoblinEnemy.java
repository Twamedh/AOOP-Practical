package game;

public class GoblinEnemy implements Enemy {
	public void attack() {
        System.out.println("Goblin enemy attack!");
    }
}
