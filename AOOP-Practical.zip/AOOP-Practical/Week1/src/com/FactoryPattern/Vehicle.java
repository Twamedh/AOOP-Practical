package com.FactoryPattern;

public interface Vehicle {
	public void drive();

}
