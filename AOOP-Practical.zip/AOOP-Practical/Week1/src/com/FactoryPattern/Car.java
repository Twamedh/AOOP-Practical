package com.FactoryPattern;

public class Car implements Vehicle {

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("I am driving a car");
	}

}

