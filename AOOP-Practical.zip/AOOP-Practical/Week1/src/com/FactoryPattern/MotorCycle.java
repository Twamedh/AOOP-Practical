package com.FactoryPattern;

public class MotorCycle implements Vehicle {

	@Override
	public void drive() {
		// TODO Auto-generated method stub
		System.out.println("I am riding a motorcycle");
	}

}
